#include <Wire.h>                                          //  I2C Library Already Part Of The Arduino Distribution

//  Global Variables
const byte Sensor_Address = 0x68;                         //  Default Address Of MPU6050 When Pin AD0 Is Not Set High

//  Sensor Data: WORD Format, Sequential Data Stored From Register 0x38, 14-Bytes Total
//  Data Order: Acceleration -> Temperature -> Rotation
int16_t Acceleration_X, Acceleration_Y, Acceleration_Z;   //  MPU6050 Sensor Supports 3-Axis Accelerometer Measurements
int16_t Rotation_X, Rotation_Y, Rotation_Z;               //  MPU6050 Sensor Supports 3-Axis Gyroscopic Measurements
int16_t Temperature;                                      //  MPU6050 Sensor Chip Temperature

void setup() {
  Serial.begin(9600);                                     //  For Displaying Data To The Serial Monitor (Communicates Over The USB Connector)
  Wire.begin();                                           //  Activate The Library

  //  Zero Inputs
  Acceleration_X  = 0;
  Acceleration_Y  = 0;
  Acceleration_Z  = 0;

  Rotation_X      = 0;
  Rotation_Y      = 0;
  Rotation_Z      = 0;

  Temperature     = 0;
}

void loop() {
  Wire.beginTransmission(Sensor_Address);               //  Tell The Sensor To Be Ready For Communication
  Wire.write(0x3B);                                     //  Specify Register 0x3B To Be The Register Where Communications Should Begin At
  Wire.endTransmission(false);                          //  End This MEssage But Do Not Close The Communications Bus 

  //  MPU6050 Sensor Data Stored In A WORD Format (High Byte & Low Byte - Big Endian Format)
  Wire.requestFrom(Sensor_Address, 14);                 //  Request All 14-Bytes Of Sensor Data At The Register Address & Sensor Address Specified Above

  //  Format The "Read" Data Into Big Endian Format By Performing A "Byte Shift" Operation
  //  Note That The Read() Function Automatically Moves The Pointer To The Next Register Address With Each Consecutive Call 
  if(Wire.available() >= 14){
    Acceleration_X  = Wire.read() << 8 | Wire.read();   //  Math Explanation: 0x3B << 8 | 0x3C = 0x3B3C
    Acceleration_Y  = Wire.read() << 8 | Wire.read();
    Acceleration_Z  = Wire.read() << 8 | Wire.read();

    Temperature     = Wire.read() << 8 | Wire.read();

    Rotation_X      = Wire.read() << 8 | Wire.read();
    Rotation_Y      = Wire.read() << 8 | Wire.read();
    Rotation_Z      = Wire.read() << 8 | Wire.read();

    Serial.print("X-Axis Acceleration: "); 
    Serial.print(Acceleration_X);
    Serial.print(", Y-Axis Acceleration: "); 
    Serial.print(Acceleration_Y);
    Serial.print(", Z-Axis Acceleration: ");
    Serial.print(Acceleration_Z);
    Serial.print(", X-Axis Gyroscope: "); 
    Serial.print(Rotation_X);
    Serial.print(", Y-Axis Gyroscope: "); 
    Serial.print(Rotation_Y);
    Serial.print(", Z-Axis Gyroscope: ");
    Serial.println(Rotation_Z);
    Serial.print(", Chip Temperature: ");
    Serial.println(Temperature);

  }
  else{
    Serial.print("Not Enough Data Is Present To Perform The Read & Byte Shift Operation");
  }

  delay(1000);                                          //  Time To Read Sensor Data Via Serial Output Monitor
}
